function variable(){
    let vari = 'pranav manoj';
    document.getElementById('qa').innerHTML = vari
}